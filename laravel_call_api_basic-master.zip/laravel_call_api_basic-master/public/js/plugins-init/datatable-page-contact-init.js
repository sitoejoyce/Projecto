(function($) {
    "use strict"

    $(".default-ordering").DataTable({
        order: [
            [3, "desc"]
        ]
    })


})(jQuery);